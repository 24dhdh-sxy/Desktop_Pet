import spec from '../../../pet-spec.json';
import type { CharacterConfig, PetSpec, StateActivity } from '../../shared/contracts';
import { exceedsDragThreshold } from '../../main/drag';
import { PetStateMachine } from './state-machine';
import './index.css';

const petSpec = spec as PetSpec;

const sprite = document.getElementById('pet-sprite') as HTMLImageElement;
const container = document.getElementById('pet-container') as HTMLDivElement;
const feedbackBubble = document.getElementById('feedback-bubble') as HTMLDivElement;

container.addEventListener('dragstart', (event) => event.preventDefault());

// 加载所有角色素材（递归包含 kiana/ 和 mei/ 子目录）
const allAssetMap = new Map<string, string>();
const assetContext = require.context('../../assets/pet', true, /\.png$/i);
for (const key of assetContext.keys()) {
  allAssetMap.set(key.replace(/^\.\//, ''), assetContext(key));
}

// 当前角色状态
let currentCharacterId: string = petSpec.currentCharacter || 'kiana';
let currentCharacter: CharacterConfig = petSpec.characters.find((c) => c.id === currentCharacterId) || petSpec.characters[0]!;
let effectiveAssetMap = new Map<string, string>();
let expectedAssetNames: string[] = [];

// 构建当前角色的有效素材映射
function buildEffectiveAssets(character: CharacterConfig): void {
  effectiveAssetMap.clear();
  const prefix = character.assetPrefix;
  for (const [fullPath, url] of allAssetMap) {
    if (fullPath.startsWith(prefix)) {
      const relativePath = fullPath.slice(prefix.length);
      effectiveAssetMap.set(relativePath, url);
    }
  }
  expectedAssetNames = [...new Set([
    character.character.coreAsset,
    ...character.states.flatMap((state) => state.frames),
  ])];
}

buildEffectiveAssets(currentCharacter);

let stateMachine = new PetStateMachine(currentCharacter.states, performance.now());
container.dataset.state = stateMachine.currentStateId();
let idleTimer: ReturnType<typeof setTimeout> | null = null;
let blinkTimer: ReturnType<typeof setTimeout> | null = null;
let animationFrame: number | null = null;
let initialized = false;

// 设置呼吸动画
function applyBreathing(): void {
  const breathing = currentCharacter.motion.breathing;
  if (breathing.enabled) {
    document.documentElement.style.setProperty('--breath-period', `${breathing.periodMs}ms`);
    document.documentElement.style.setProperty('--breath-scale-x', `${1 + breathing.scaleX}`);
    document.documentElement.style.setProperty('--breath-scale-y', `${1 + breathing.scaleY}`);
  }
}
applyBreathing();

// 挤压回弹
function playSquash(): void {
  if (!currentCharacter.motion.squashStretch.enabled) return;
  const squash = currentCharacter.motion.squashStretch;
  document.documentElement.style.setProperty('--squash-duration', `${squash.durationMs}ms`);
  document.documentElement.style.setProperty('--squash-intensity', `${squash.intensity}`);
  sprite.classList.remove('squash');
  void sprite.offsetWidth;
  sprite.classList.add('squash');
}

function showFeedback(text: string): void {
  feedbackBubble.textContent = text;
  feedbackBubble.classList.add('show');
  setTimeout(() => {
    feedbackBubble.classList.remove('show');
  }, 2000);
}

function setState(stateId: string, durationMs?: number): void {
  if (!stateMachine.start(stateId, performance.now(), durationMs)) return;
  const snapshot = stateMachine.tick(performance.now());
  container.dataset.state = snapshot.stateId;
  const frameUrl = effectiveAssetMap.get(snapshot.frame);
  if (frameUrl) sprite.src = frameUrl;
}

function animate(timestamp: number): void {
  const snapshot = stateMachine.tick(timestamp);
  container.dataset.state = snapshot.stateId;
  if (snapshot.stateChanged) {
    const frameUrl = effectiveAssetMap.get(snapshot.frame);
    if (frameUrl) sprite.src = frameUrl;
  }
  animationFrame = requestAnimationFrame(animate);
}

function scheduleIdleEvents(): void {
  if (blinkTimer) clearTimeout(blinkTimer);
  if (idleTimer) clearTimeout(idleTimer);

  const blinkDelay = 2000 + Math.random() * 4000;
  blinkTimer = setTimeout(() => {
    if (stateMachine.currentStateId() === 'idle') {
      setState('blink');
    }
    scheduleIdleEvents();
  }, blinkDelay);

  const idleMin = currentCharacter.motion.idleIntervalMs.min;
  const idleMax = currentCharacter.motion.idleIntervalMs.max;
  const idleDelay = idleMin + Math.random() * (idleMax - idleMin);
  idleTimer = setTimeout(() => {
    scheduleIdleEvents();
  }, idleDelay);
}

// 角色切换
async function switchCharacter(characterId: string): Promise<void> {
  const character = petSpec.characters.find((c) => c.id === characterId);
  if (!character) return;
  if (character.id === currentCharacterId) return;

  currentCharacterId = character.id;
  currentCharacter = character;
  buildEffectiveAssets(character);
  stateMachine.updateStates(character.states, performance.now());
  applyBreathing();

  // 切换到 idle 状态
  const snapshot = stateMachine.tick(performance.now());
  container.dataset.state = snapshot.stateId;
  const frameUrl = effectiveAssetMap.get(snapshot.frame);
  if (frameUrl) sprite.src = frameUrl;

  scheduleIdleEvents();
}

container.addEventListener('click', () => {
  if (suppressNextClick) {
    suppressNextClick = false;
    return;
  }
  playSquash();
  setState('happy');
  scheduleIdleEvents();
});

let isDragging = false;
let pointerStart = { x: 0, y: 0 };
let activePointerId: number | undefined;
let dragUpdatePending = false;
let suppressNextClick = false;
let dragBegin: Promise<void> | undefined;

container.addEventListener('pointerdown', (event) => {
  if (event.button !== 0 || activePointerId !== undefined) return;
  activePointerId = event.pointerId;
  pointerStart = { x: event.clientX, y: event.clientY };
  container.setPointerCapture(event.pointerId);
});

container.addEventListener('pointermove', (event) => {
  if (event.pointerId !== activePointerId) return;
  if (!isDragging && exceedsDragThreshold(pointerStart, { x: event.clientX, y: event.clientY })) {
    isDragging = true;
    dragBegin = window.petAPI?.window.beginDrag() ?? Promise.resolve();
  }
  if (!isDragging) return;
  if (dragUpdatePending) return;
  dragUpdatePending = true;
  requestAnimationFrame(() => {
    void (dragBegin ?? Promise.resolve())
      .then(() => window.petAPI?.window.updateDrag())
      .catch(() => {})
      .finally(() => { dragUpdatePending = false; });
  });
});

function finishPointer(event: PointerEvent): void {
  if (event.pointerId !== activePointerId) return;
  if (container.hasPointerCapture(event.pointerId)) container.releasePointerCapture(event.pointerId);
  activePointerId = undefined;
  const dragged = isDragging;
  isDragging = false;
  dragUpdatePending = false;
  if (dragged) {
    suppressNextClick = true;
    void (dragBegin ?? Promise.resolve())
      .then(() => window.petAPI?.window.endDrag())
      .catch(() => {});
  }
  dragBegin = undefined;
}

container.addEventListener('pointerup', finishPointer);
container.addEventListener('pointercancel', finishPointer);

container.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  window.petAPI?.window.showContextMenu().catch(() => {});
});

window.petAPI?.events.onStateActivity((activity: StateActivity) => {
  if (activity.stateId) {
    setState(activity.stateId, activity.durationMs);
    scheduleIdleEvents();
  }
  if (activity.feedback) {
    showFeedback(activity.feedback);
  }
});

window.petAPI?.events.onCharacterSwitch((character) => {
  void switchCharacter(character.id);
});

async function init(): Promise<void> {
  try {
    const loadedAssets = await Promise.all(expectedAssetNames.map((name) => new Promise<HTMLImageElement>((resolve, reject) => {
      const url = effectiveAssetMap.get(name);
      if (!url) {
        reject(new Error(`Missing runtime asset: ${name}`));
        return;
      }
      const image = new Image();
      image.onload = () => {
        if (image.naturalWidth <= 0 || image.naturalHeight <= 0) reject(new Error(`Runtime asset has invalid dimensions: ${name}`));
        else resolve(image);
      };
      image.onerror = () => reject(new Error(`Runtime asset failed to decode: ${name}`));
      image.src = url;
    })));
    const reference = loadedAssets[0];
    if (!reference) throw new Error('No runtime assets were loaded');
    const invalidSize = loadedAssets.find((image) => image.naturalWidth !== reference.naturalWidth || image.naturalHeight !== reference.naturalHeight);
    if (invalidSize) throw new Error('Runtime assets do not share one decoded frame size');

    setState('idle');
    scheduleIdleEvents();
    animationFrame = requestAnimationFrame(animate);
    initialized = true;

    await window.petAPI?.runtime.ready({
      status: 'ready',
      stateId: 'idle',
      frame: currentCharacter.states.find((s) => s.id === 'idle')?.frames[0] ?? '',
      assetCount: loadedAssets.length,
      expectedAssetCount: expectedAssetNames.length,
      naturalWidth: reference.naturalWidth,
      naturalHeight: reference.naturalHeight,
      petVisible: true,
      ipcReady: true,
      characterId: currentCharacterId,
    });
  } catch (error) {
    window.petAPI?.runtime.fail({
      message: error instanceof Error ? error.message : String(error),
    }).catch(() => {});
  }
}

init();
