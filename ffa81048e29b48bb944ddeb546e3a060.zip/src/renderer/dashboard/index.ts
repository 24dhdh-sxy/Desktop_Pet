import spec from '../../../pet-spec.json';
import type { CharacterInfo, PetSpec, PetStats, Settings, InteractionSpec } from '../../shared/contracts';
import './index.css';

// 递归导入所有运行时素材（用于 asset link 检查）
require.context('../../assets/pet', true, /\.png$/);

const petSpec = spec as PetSpec;
let currentCharacterId: string = petSpec.currentCharacter || 'kiana';

function getCharacterConfig(id: string) {
  return petSpec.characters.find((c) => c.id === id) || petSpec.characters[0]!;
}

function applyTheme(characterId: string): void {
  const character = getCharacterConfig(characterId);
  const theme = character.experience.theme;
  document.documentElement.style.setProperty('--primary', theme.primary);
  document.documentElement.style.setProperty('--accent', theme.accent);
  document.documentElement.style.setProperty('--background', theme.background);
  document.documentElement.style.setProperty('--surface', theme.surface);
  document.documentElement.style.setProperty('--text', theme.text);
  document.documentElement.style.setProperty('--muted', theme.muted);
  document.documentElement.style.setProperty('--radius', `${theme.cornerRadius}px`);
  document.title = `${character.character.displayName}的小屋`;
  document.getElementById('pet-name')!.textContent = character.character.displayName;
  document.getElementById('pet-personality')!.textContent = character.character.personality.join('、');
}

applyTheme(currentCharacterId);

const closeBtn = document.getElementById('close-btn') as HTMLButtonElement;
const affectionEl = document.getElementById('affection') as HTMLDivElement;
const moodEl = document.getElementById('mood') as HTMLDivElement;
const todayInteractionsEl = document.getElementById('today-interactions') as HTMLDivElement;
const companionMinutesEl = document.getElementById('companion-minutes') as HTMLDivElement;
const interactionsList = document.getElementById('interactions-list') as HTMLDivElement;
const characterSelector = document.getElementById('character-selector') as HTMLDivElement;
const toggleAlwaysOnTop = document.getElementById('toggle-always-on-top') as HTMLDivElement;
const toggleClickThrough = document.getElementById('toggle-click-through') as HTMLDivElement;
const sizeSelector = document.getElementById('size-selector') as HTMLDivElement;

let currentSettings: Settings | null = null;

async function loadCharacters(): Promise<void> {
  try {
    const characters = await window.petAPI?.character.list();
    const current = await window.petAPI?.character.current();
    if (!characters) return;
    currentCharacterId = current?.id || currentCharacterId;

    characterSelector.replaceChildren();
    for (const character of characters) {
      const btn = document.createElement('button');
      btn.className = 'character-btn' + (character.id === currentCharacterId ? ' active' : '');
      btn.textContent = character.displayName;
      btn.dataset.characterId = character.id;
      btn.addEventListener('click', async () => {
        try {
          const result = await window.petAPI?.character.switch(character.id);
          if (result) {
            currentCharacterId = character.id;
            applyTheme(character.id);
            updateCharacterButtons();
            await loadInteractions();
            updateStats(result.stats);
          }
        } catch (error) {
          console.error('Failed to switch character:', error);
        }
      });
      characterSelector.appendChild(btn);
    }
  } catch (error) {
    console.error('Failed to load characters:', error);
  }
}

function updateCharacterButtons(): void {
  const btns = characterSelector.querySelectorAll('.character-btn');
  btns.forEach((btn) => {
    if ((btn as HTMLElement).dataset.characterId === currentCharacterId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
}

async function loadInteractions(): Promise<void> {
  try {
    const interactions = await window.petAPI?.interactions.list();
    if (!interactions) return;

    interactionsList.replaceChildren();
    for (const interaction of interactions) {
      const btn = document.createElement('button');
      btn.className = 'interaction-btn';
      const emoji = document.createElement('span');
      emoji.textContent = interaction.emoji;
      const label = document.createElement('span');
      label.textContent = interaction.label;
      btn.append(emoji, label);
      btn.addEventListener('click', async () => {
        try {
          await window.petAPI?.interactions.trigger(interaction.id);
        } catch (error) {
          console.error('Failed to trigger interaction:', error);
        }
      });
      interactionsList.appendChild(btn);
    }
  } catch (error) {
    console.error('Failed to load interactions:', error);
  }
}

async function loadSettings(): Promise<void> {
  try {
    const settings = await window.petAPI?.settings.get();
    if (!settings) return;
    currentSettings = settings;
    if (settings.currentCharacter) {
      currentCharacterId = settings.currentCharacter;
      applyTheme(currentCharacterId);
    }

    if (settings.alwaysOnTop) {
      toggleAlwaysOnTop.classList.add('active');
    } else {
      toggleAlwaysOnTop.classList.remove('active');
    }

    if (settings.clickThrough) {
      toggleClickThrough.classList.add('active');
    } else {
      toggleClickThrough.classList.remove('active');
    }

    const sizeBtns = sizeSelector.querySelectorAll('.size-btn');
    sizeBtns.forEach((btn) => {
      const scale = parseFloat((btn as HTMLElement).dataset.scale || '1');
      if (Math.abs(scale - settings.petScale) < 0.01) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

async function loadStats(): Promise<void> {
  try {
    const stats = await window.petAPI?.interactions.stats();
    if (!stats) return;
    updateStats(stats);
  } catch (error) {
    console.error('Failed to load stats:', error);
  }
}

function updateStats(stats: PetStats): void {
  affectionEl.textContent = String(stats.affection);
  moodEl.textContent = String(stats.mood);
  todayInteractionsEl.textContent = String(stats.todayInteractions);
  const unit = document.createElement('small');
  unit.textContent = '分钟';
  companionMinutesEl.replaceChildren(String(stats.companionMinutes), unit);
}

closeBtn.addEventListener('click', async () => {
  await window.petAPI?.window.hideDashboard();
});

toggleAlwaysOnTop.addEventListener('click', async () => {
  if (!currentSettings) return;
  const newVal = !currentSettings.alwaysOnTop;
  try {
    await window.petAPI?.settings.update({ alwaysOnTop: newVal });
    currentSettings.alwaysOnTop = newVal;
    if (newVal) {
      toggleAlwaysOnTop.classList.add('active');
    } else {
      toggleAlwaysOnTop.classList.remove('active');
    }
  } catch (error) {
    console.error('Failed to update setting:', error);
  }
});

toggleClickThrough.addEventListener('click', async () => {
  if (!currentSettings) return;
  const newVal = !currentSettings.clickThrough;
  try {
    await window.petAPI?.settings.update({ clickThrough: newVal });
    currentSettings.clickThrough = newVal;
    if (newVal) {
      toggleClickThrough.classList.add('active');
    } else {
      toggleClickThrough.classList.remove('active');
    }
  } catch (error) {
    console.error('Failed to update setting:', error);
  }
});

sizeSelector.addEventListener('click', async (e) => {
  const target = e.target as HTMLElement;
  if (!target.classList.contains('size-btn')) return;
  if (!currentSettings) return;

  const scale = parseFloat(target.dataset.scale || '1');
  try {
    await window.petAPI?.settings.update({ petScale: scale });
    currentSettings.petScale = scale;

    const sizeBtns = sizeSelector.querySelectorAll('.size-btn');
    sizeBtns.forEach((btn) => btn.classList.remove('active'));
    target.classList.add('active');
  } catch (error) {
    console.error('Failed to update pet scale:', error);
  }
});

window.petAPI?.events.onStats((stats: PetStats) => {
  updateStats(stats);
});

window.petAPI?.events.onCharacterSwitch((character: CharacterInfo) => {
  currentCharacterId = character.id;
  applyTheme(character.id);
  updateCharacterButtons();
  void loadInteractions();
  void loadStats();
});

async function init(): Promise<void> {
  await loadCharacters();
  await loadInteractions();
  await loadSettings();
  await loadStats();
}

init();
